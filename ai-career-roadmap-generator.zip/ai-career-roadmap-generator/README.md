# PathPilot — AI Career Roadmap Generator

A full-stack React + Express career planning starter.

## Run in VS Code

Requirements: Node.js 18+ and npm.

1. Extract this ZIP and open the `ai-career-roadmap-generator` folder in VS Code.
2. Open Terminal in VS Code.
3. Install dependencies:
   ```bash
   npm run install:all
   ```
4. Optional: copy `server/.env.example` to `server/.env` and add a Gemini API key.
5. Start both frontend and backend:
   ```bash
   npm run dev
   ```
6. Open `http://localhost:5173`.

Without a Gemini API key, the app uses its built-in career roadmap generator. Gemini keys belong only in `server/.env`; never put them in frontend code or commit them to Git.

## Included features

- Student profile: name, education, degree/branch and graduation year
- Career path, experience level, study duration, daily hours and goal
- Existing skills input and indicative skill-gap match
- Personalized phased roadmap, learning tasks and project ideas
- Interactive roadmap progress checklist
- Learning resources and certification suggestions
- Interview preparation checklist
- Related career path suggestions
- Export roadmap as a text file
- Gemini API integration with a built-in fallback

## API

- `GET /api/health` — server health check
- `POST /api/roadmap` — generate a roadmap from the submitted profile

## Important

The skill match is a simple indicative comparison, not a formal assessment. Check certification providers for current eligibility, exam availability and fees before enrolling.

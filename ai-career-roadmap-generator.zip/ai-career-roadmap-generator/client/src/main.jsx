import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Compass, Sparkles, Target, Clock3, GraduationCap, BriefcaseBusiness, Download, CheckCircle2, Code2, BookOpen, Rocket, ArrowRight, LoaderCircle } from 'lucide-react';
import './style.css';

const initial = { name:'', education:'Undergraduate', degree:'', graduationYear:'2027', existingSkills:'', career:'Full Stack Developer', level:'Beginner', duration:'4', goal:'Get an internship or placement', hours:'2' };

function App() {
  const [form, setForm] = useState(initial);
  const [roadmap, setRoadmap] = useState(null);
  const [checked, setChecked] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [interviewDone, setInterviewDone] = useState({});
  const update = (key, value) => setForm(v => ({...v, [key]:value}));
  const totalTasks = roadmap?.phases?.reduce((n,p) => n + p.tasks.length, 0) || 0;
  const completed = Object.values(checked).filter(Boolean).length;
  const progress = totalTasks ? Math.round(completed / totalTasks * 100) : 0;

  async function generate(e) {
    e.preventDefault(); setLoading(true); setError(''); setRoadmap(null); setChecked({}); setInterviewDone({});
    try {
      const response = await fetch('/api/roadmap', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(form) });
      if (!response.ok) throw new Error('Could not generate roadmap. Please try again.');
      const data = await response.json(); setRoadmap(data.roadmap);
      setTimeout(() => document.getElementById('results')?.scrollIntoView({behavior:'smooth'}), 100);
    } catch (err) { setError(err.message || 'Something went wrong.'); }
    finally { setLoading(false); }
  }

  function download() {
    if (!roadmap) return;
    const content = [
      roadmap.title, roadmap.summary, '', 'SKILL GAP ANALYSIS', `Skill match: ${roadmap.skillGap?.matchPercent ?? 0}%`, 'Already know:', ...(roadmap.skillGap?.matched || []).map(x=>'• '+x), 'Skills to develop:', ...(roadmap.skillGap?.missing || []).map(x=>'• '+x), '', 'TARGET ROLES', ...(roadmap.roles || []).map(x=>'• '+x), '',
      'SKILLS', ...(roadmap.skills || []).map(x=>'• '+x), '', 'PROJECTS', ...(roadmap.projects || []).map(x=>'• '+x), '',
      'ROADMAP', ...roadmap.phases.flatMap(p=>[p.period+' — '+p.title, ...p.tasks.map(t=>'  • '+t)]), '',
      'LEARNING RESOURCES', ...(roadmap.resources || []).map(x=>`• ${x.name} — ${x.url}`), '',
      'CERTIFICATIONS', ...(roadmap.certifications || []).map(x=>`• ${x.name} (${x.provider}) — ${x.url}`), '',
      'INTERVIEW PREPARATION', ...(roadmap.interviewPrep || []).map(x=>'• '+x), '',
      'ALTERNATIVE CAREERS', ...(roadmap.alternativeCareers || []).map(x=>'• '+x), '',
      'WEEKLY ROUTINE', ...(roadmap.weeklyPlan || []).map(x=>'• '+x)
    ].join('\n');
    const url = URL.createObjectURL(new Blob([content], {type:'text/plain'}));
    const a = document.createElement('a'); a.href=url; a.download='my-career-roadmap.txt'; a.click(); URL.revokeObjectURL(url);
  }

  return <div className="shell">
    <header className="topbar"><a className="logo" href="#"><span className="logo-icon"><Compass size={20}/></span> PathPilot</a><span className="top-label">AI CAREER PLANNER</span></header>
    <main>
      <section className="hero">
        <div className="eyebrow"><Sparkles size={14}/> PLAN YOUR NEXT CHAPTER</div>
        <h1>Your career journey,<br/><span>made clear.</span></h1>
        <p>Turn your goals into a practical roadmap. Discover what to learn, which projects to build, and how to prepare for your dream role.</p>
        <div className="hero-pills"><span><CheckCircle2 size={15}/> Personalized plan</span><span><CheckCircle2 size={15}/> Project milestones</span><span><CheckCircle2 size={15}/> Weekly action plan</span></div>
      </section>

      <section className="builder-card">
        <div className="section-heading"><div><div className="eyebrow small">LET'S GET STARTED</div><h2>Build your career roadmap</h2><p>Share a few details so we can tailor your plan.</p></div><div className="heading-icon"><Target size={23}/></div></div>
        <form onSubmit={generate}>
          <div className="field full"><label>Your name <span>Optional</span></label><input value={form.name} onChange={e=>update('name',e.target.value)} placeholder="e.g. Harini"/></div>
          <div className="form-grid">
            <div className="field"><label>Education level</label><select value={form.education} onChange={e=>update('education',e.target.value)}>{['High School','Diploma','Undergraduate','Postgraduate','Graduate','Other'].map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="field"><label>Degree / Branch</label><input value={form.degree} onChange={e=>update('degree',e.target.value)} placeholder="e.g. B.Tech CSE"/></div>
            <div className="field"><label>Graduation year</label><select value={form.graduationYear} onChange={e=>update('graduationYear',e.target.value)}>{Array.from({length:9},(_,i)=>String(new Date().getFullYear()+i)).map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="field"><label>Career path</label><select value={form.career} onChange={e=>update('career',e.target.value)}>{['Frontend Developer','Backend Developer','Full Stack Developer','Java Developer','Data Analyst','AI / ML Engineer','Cybersecurity Analyst','Cloud Engineer','UI/UX Designer'].map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="field"><label>Current skill level</label><select value={form.level} onChange={e=>update('level',e.target.value)}>{['Beginner','Intermediate','Advanced'].map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="field"><label>Roadmap duration</label><select value={form.duration} onChange={e=>update('duration',e.target.value)}>{['2','3','4','6','9','12'].map(x=><option key={x} value={x}>{x} months</option>)}</select></div>
            <div className="field"><label>Study time per day</label><select value={form.hours} onChange={e=>update('hours',e.target.value)}>{['1','2','3','4','5+'].map(x=><option key={x} value={x}>{x} hours</option>)}</select></div>
          </div>
          <div className="field full"><label>Skills you already know <span>Separate with commas</span></label><textarea rows="3" value={form.existingSkills} onChange={e=>update('existingSkills',e.target.value)} placeholder="e.g. Python, SQL, Excel, HTML" /></div>
          <div className="field full"><label>Main goal</label><select value={form.goal} onChange={e=>update('goal',e.target.value)}>{['Get an internship or placement','Prepare for campus placements','Switch to a new career','Build strong practical skills','Prepare for freelance work'].map(x=><option key={x}>{x}</option>)}</select></div>
          {error && <div className="error">{error}</div>}
          <button className="generate" disabled={loading}>{loading ? <><LoaderCircle className="spin" size={18}/> Creating your roadmap...</> : <><Sparkles size={17}/> Generate my roadmap <ArrowRight size={17}/></>}</button>
        </form>
      </section>

      {roadmap && <section id="results" className="results">
        <div className="result-top"><div><div className="eyebrow small"><Sparkles size={13}/> YOUR PERSONALIZED PLAN</div><h2>{roadmap.title}</h2><p>{roadmap.summary}</p></div><button className="download" onClick={download}><Download size={16}/> Export plan</button></div>
        <div className="progress-card"><div className="progress-meta"><span>Roadmap progress</span><strong>{progress}%</strong></div><div className="progress-track"><div style={{width:progress+'%'}}/></div><small>{completed} of {totalTasks} milestones completed</small></div>
        {roadmap.skillGap && <section className="gap-card"><div className="gap-heading"><div><div className="eyebrow small">PERSONAL SKILL CHECK</div><h2>Skill Gap Analysis</h2><p>Compare your current skills with the skills needed for {form.career}.</p></div><div className="match-score"><strong>{roadmap.skillGap.matchPercent}%</strong><span>skill match</span></div></div><div className="match-track"><div style={{width:roadmap.skillGap.matchPercent+'%'}}/></div><div className="gap-columns"><div><h3><CheckCircle2 size={16}/> Skills you know</h3>{roadmap.skillGap.matched.length ? roadmap.skillGap.matched.map((x,i)=><span className="gap-pill known" key={i}>{x}</span>) : <p className="muted">No matching skills entered yet.</p>}</div><div><h3><Target size={16}/> Skills to develop</h3>{roadmap.skillGap.missing.length ? roadmap.skillGap.missing.map((x,i)=><span className="gap-pill missing" key={i}>{x}</span>) : <p className="muted">Great! You listed all core skills.</p>}</div></div><p className="gap-note">This is an indicative match based on the skills you entered, not a formal assessment.</p></section>}
        <div className="info-grid">
          <article className="info-card"><div className="info-icon purple"><Code2/></div><h3>Core skills</h3><ul>{roadmap.skills.map((s,i)=><li key={i}>{s}</li>)}</ul></article>
          <article className="info-card"><div className="info-icon orange"><Rocket/></div><h3>Portfolio projects</h3><ul>{roadmap.projects.map((s,i)=><li key={i}>{s}</li>)}</ul></article>
          <article className="info-card"><div className="info-icon green"><BriefcaseBusiness/></div><h3>Target roles</h3><ul>{roadmap.roles.map((s,i)=><li key={i}>{s}</li>)}</ul></article>
        </div>
        <div className="roadmap-heading"><div><div className="eyebrow small">YOUR ACTION PLAN</div><h2>Step-by-step roadmap</h2></div><span className="duration-chip"><Clock3 size={14}/> {form.duration} months</span></div>
        <div className="timeline">{roadmap.phases.map((phase,i)=><article className="phase" key={i}><div className="phase-marker">{String(i+1).padStart(2,'0')}</div><div className="phase-body"><div className="phase-period">{phase.period}</div><h3>{phase.title}</h3><div className="task-list">{phase.tasks.map((task,j)=>{const id=i+'-'+j;return <label className={'task '+(checked[id]?'is-checked':'')} key={id}><input type="checkbox" checked={!!checked[id]} onChange={e=>setChecked(v=>({...v,[id]:e.target.checked}))}/><span>{task}</span></label>})}</div></div></article>)}</div>
        <div className="weekly-card"><div className="weekly-icon"><BookOpen/></div><div><h3>Your weekly routine</h3>{roadmap.weeklyPlan.map((x,i)=><p key={i}>{x}</p>)}</div></div>
        <div className="tip-card"><Sparkles size={18}/><div><strong>PathPilot tip</strong><p>{roadmap.advice}</p></div></div>

        <div className="extra-heading"><div><div className="eyebrow small">KEEP LEARNING</div><h2>Recommended learning resources</h2></div></div>
        <div className="extra-grid">
          {(roadmap.resources || []).map((item,i)=><article className="extra-card" key={i}><div className="extra-card-top"><BookOpen size={18}/><span>LEARNING RESOURCE</span></div><h3>{item.name}</h3><p>{item.type}</p><a href={item.url} target="_blank" rel="noreferrer">Open resource <ArrowRight size={14}/></a></article>)}
        </div>

        <div className="extra-heading"><div><div className="eyebrow small">BOOST YOUR PROFILE</div><h2>Suggested certifications</h2></div></div>
        <div className="extra-grid">
          {(roadmap.certifications || []).map((item,i)=><article className="extra-card" key={i}><div className="extra-card-top certificate"><GraduationCap size={18}/><span>CERTIFICATION</span></div><h3>{item.name}</h3><p>{item.provider}</p><a href={item.url} target="_blank" rel="noreferrer">View certification <ArrowRight size={14}/></a></article>)}
        </div>

        <div className="extra-heading"><div><div className="eyebrow small">GET INTERVIEW-READY</div><h2>Interview preparation checklist</h2><p>Tick each item as you prepare.</p></div></div>
        <div className="interview-card">
          {(roadmap.interviewPrep || []).map((item,i)=><label className={'interview-task '+(interviewDone[i]?'is-checked':'')} key={i}><input type="checkbox" checked={!!interviewDone[i]} onChange={e=>setInterviewDone(v=>({...v,[i]:e.target.checked}))}/><span>{item}</span></label>)}
          <div className="interview-progress">{Object.values(interviewDone).filter(Boolean).length} of {(roadmap.interviewPrep || []).length} preparation items completed</div>
        </div>

        <div className="extra-heading"><div><div className="eyebrow small">EXPLORE YOUR OPTIONS</div><h2>Related career paths</h2></div></div>
        <div className="alternative-list">{(roadmap.alternativeCareers || []).map((role,i)=><span key={i}><Target size={15}/>{role}</span>)}</div>
      </section>}
      <footer>PathPilot <span>·</span> Make progress one step at a time.</footer>
    </main>
  </div>;
}
createRoot(document.getElementById('root')).render(<App/>);
